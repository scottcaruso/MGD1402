//
//  HighScoresScene.h
//  MGD1402
//
//  Created by Scott Caruso on 2/24/14.
//  Copyright 2014 Scott Caruso. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "cocos2d-ui.h"
#import "IntroScene.h"

@interface HighScoresScene : CCScene

+ (HighScoresScene *)scene;
- (id)init;
-(void)getHighScores;

@end
