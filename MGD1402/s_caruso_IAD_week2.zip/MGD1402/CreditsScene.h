//
//  CreditsScene.h
//  MGD1402
//
//  Created by Scott Caruso on 2/24/14.
//  Copyright 2014 Scott Caruso. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "IntroScene.h"

@interface CreditsScene : CCScene
    
+ (CreditsScene *)scene;
- (id)init;

@end
