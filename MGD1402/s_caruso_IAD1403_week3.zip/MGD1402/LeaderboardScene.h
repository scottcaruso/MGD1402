//
//  LeaderboardScene.h
//  MGD1402
//
//  Created by Scott Caruso on 3/20/14.
//  Copyright 2014 Scott Caruso. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "cocos2d-ui.h"
#import "IntroScene.h"
#import "LeaderboardsAndSignIn.h"
#import <Social/Social.h>
#import <Accounts/Accounts.h>

@interface LeaderboardScene : CCScene

+ (LeaderboardScene *)scene;
-(void)retrieveHighScores:(int)numberOfSeconds;

@end
